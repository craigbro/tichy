#!/bin/sh

rm ./logs/chat.log
rm ./logs/chat.xml
./server.sh < testcase.txt
